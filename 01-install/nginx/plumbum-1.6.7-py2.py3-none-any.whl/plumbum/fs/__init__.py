"""
file-system related operations
"""