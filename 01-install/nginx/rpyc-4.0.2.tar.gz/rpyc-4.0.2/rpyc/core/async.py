"""Backward compatibility alias on py<=3.6."""
from rpyc.core.async_ import *
